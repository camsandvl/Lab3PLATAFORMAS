#include <iostream>
#include <iomanip>   // Para setw y formato tabular
#include <limits>    // Para limpiar el buffer
using namespace std;

// Función para mostrar la tabla ASCII
void mostrarTablaASCII() {
    cout << "\n=== Tabla ASCII completa (0–127) ===\n\n";
    cout << left << setw(10) << "Decimal" << "Caracter\n";
    cout << "----------------------\n";
    for (int i = 0; i <= 127; i++) {
        char c = static_cast<char>(i);
        cout << left << setw(10) << i;

        // Mostrar carácter visible, o etiqueta para los invisibles
        if (i < 32 || i == 127) {
            cout << "[No visible]";
        } else {
            cout << c;
        }
        cout << endl;
    }
}

// Función para convertir número a carácter ASCII
void convertirNumeroAASCII() {
    int num;
    while (true) {
        cout << "Ingrese un número entre 0 y 127: ";
        cin >> num;

        if (cin.fail() || num < 0 || num > 127) {
            cout << "Error: número inválido. Debe estar entre 0 y 127.\n";
            cin.clear(); // Limpiar error
            cin.ignore(numeric_limits<streamsize>::max(), '\n');
        } else {
            char c = static_cast<char>(num);
            cout << "El carácter ASCII correspondiente es: ";
            if (num < 32 || num == 127) {
                cout << "[No visible]" << endl;
            } else {
                cout << c << endl;
            }
            break;
        }
    }
}

int main() {
    int opcion;

    cout << "=== Conversor Decimal – ASCII ===\n";
    cout << "Seleccione una opción:\n";
    cout << "[1] Ver tabla ASCII completa\n";
    cout << "[2] Convertir número a carácter ASCII\n";
    cout << "Opción: ";
    cin >> opcion;

    if (cin.fail()) {
        cout << "Entrada inválida. Debe ingresar un número.\n";
        return 1;
    }

    switch (opcion) {
        case 1:
            mostrarTablaASCII();
            break;
        case 2:
            convertirNumeroAASCII();
            break;
        default:
            cout << "Opción no válida.\n";
            break;
    }

    return 0;
}
