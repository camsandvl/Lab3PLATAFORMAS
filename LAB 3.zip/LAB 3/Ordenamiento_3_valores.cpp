#include <iostream>
#include <algorithm> // Para std::sort
#include <limits>    // Para limpiar el buffer en caso de error
using namespace std;

// Función auxiliar para leer un número con validación
double leerNumero(int indice) {
    double valor;
    while (true) {
        cout << "Ingrese el número " << indice << ": ";
        cin >> valor;

        if (cin.fail()) {
            cout << "Error: ingrese un valor numérico válido.\n";
            cin.clear(); // Limpia el error
            cin.ignore(numeric_limits<streamsize>::max(), '\n'); // Limpia el buffer
        } else {
            return valor;
        }
    }
}

int main() {
    cout << "=== Ordenamiento de tres valores ===\n\n";

    // Entrada
    double numeros[3];
    for (int i = 0; i < 3; i++) {
        numeros[i] = leerNumero(i + 1);
    }

    // Proceso: ordenar usando std::sort
    sort(numeros, numeros + 3);

    // Salida
    cout << "\nNúmeros ordenados en orden ascendente:\n";
    for (int i = 0; i < 3; i++) {
        cout << numeros[i] << " ";
    }
    cout << endl;

    return 0;
}
