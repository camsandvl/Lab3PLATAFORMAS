#include <iostream>
#include <iomanip>  // Para mostrar decimales y tabular
#include <limits>   // Para limpiar el buffer
#include <cmath>    // Para pow()
using namespace std;

// Estructura Persona
struct Persona {
    string nombre;
    char sexo;
    int edad;
    double peso;
    double altura;
};

// Función para calcular grasa corporal
double calcularGrasa(const Persona& p) {
    double imc = p.peso / pow(p.altura, 2);
    double grasa = 0;

    switch (toupper(p.sexo)) {
        case 'M':
            grasa = (1.20 * imc) + (0.23 * p.edad) - 16.2;
            break;
        case 'F':
            grasa = (1.20 * imc) + (0.23 * p.edad) - 5.4;
            break;
        default:
            cout << "Error: Sexo no válido (debe ser M o F)\n";
            return -1;
    }

    return grasa;
}

// Función auxiliar para limpiar errores de entrada
void limpiarEntrada() {
    cin.clear();
    cin.ignore(numeric_limits<streamsize>::max(), '\n');
}

int main() {
    Persona p;

    cout << "=== Cálculo de grasa corporal ===\n\n";

    // Entrada
    cout << "Nombre: ";
    getline(cin, p.nombre);

    while (true) {
        cout << "Sexo (M/F): ";
        cin >> p.sexo;
        p.sexo = toupper(p.sexo);
        if (p.sexo != 'M' && p.sexo != 'F') {
            cout << "Error: ingrese M o F.\n";
            limpiarEntrada();
        } else {
            break;
        }
    }

    cout << "Edad (años): ";
    while (!(cin >> p.edad) || p.edad <= 0) {
        cout << "Error: ingrese una edad válida.\n";
        limpiarEntrada();
    }

    cout << "Peso (kg): ";
    while (!(cin >> p.peso) || p.peso <= 0) {
        cout << "Error: ingrese un peso válido.\n";
        limpiarEntrada();
    }

    cout << "Altura (m): ";
    while (!(cin >> p.altura) || p.altura <= 0) {
        cout << "Error: ingrese una altura válida.\n";
        limpiarEntrada();
    }

    // Proceso
    double grasa = calcularGrasa(p);

    // Salida
    if (grasa != -1) {
        cout << fixed << setprecision(2);
        cout << "\n--- Reporte de Composición Corporal ---\n";
        cout << left << setw(15) << "Nombre" << setw(8) << "Sexo" << setw(6) << "Edad"
             << setw(8) << "Peso" << setw(8) << "Altura" << setw(10) << "% Grasa" << endl;
        cout << string(60, '-') << endl;
        cout << left << setw(15) << p.nombre << setw(8) << p.sexo << setw(6) << p.edad
             << setw(8) << p.peso << setw(8) << p.altura << setw(10) << grasa << endl;
    }

    return 0;
}
