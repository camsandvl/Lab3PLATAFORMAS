#include <iostream>
#include <limits> // Para limpiar el buffer en caso de error de entrada
using namespace std;

// Función modular
double calcularUtilidad(int cantidad, double costo, double precio) {
    double utilidadUnidad = precio - costo;
    return utilidadUnidad * cantidad;
}

// Función auxiliar para validar que un número sea mayor a 0
template <typename T>
T leerEntradaPositiva(const string& mensaje) {
    T valor;
    while (true) {
        cout << mensaje;
        cin >> valor;

        if (cin.fail() || valor <= 0) {
            cout << "Error: Ingrese un valor numérico válido y mayor a 0.\n";
            cin.clear(); // limpia el error
            cin.ignore(numeric_limits<streamsize>::max(), '\n'); // limpia el buffer
        } else {
            return valor;
        }
    }
}

int main() {
    cout << "=== Cálculo de utilidad total de una venta ===\n\n";

    // Entrada con validación
    int cantidad = leerEntradaPositiva<int>("Ingrese la cantidad vendida: ");
    double costo = leerEntradaPositiva<double>("Ingrese el costo por unidad: Q");
    double precio = leerEntradaPositiva<double>("Ingrese el precio de venta por unidad: Q");

    // Proceso
    double utilidad = calcularUtilidad(cantidad, costo, precio);

    // Salida
    cout << "\nUtilidad total: Q" << utilidad << endl;

    return 0;
}
