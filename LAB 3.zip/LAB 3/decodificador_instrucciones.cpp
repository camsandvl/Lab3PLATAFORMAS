#include <iostream>
#include <sstream>
#include <vector>
#include <cmath>
using namespace std;

// Operaciones
int suma(int a, int b) { return a + b; }
int resta(int a, int b) { return a - b; }
int multiplicacion(int a, int b) { return a * b; }
int division(int a, int b) {
    if (b == 0) throw runtime_error("Error. División por cero");
    return a / b;
}
int potencia(int a, int b) { return pow(a, b); }
int mod(int a, int b) {
    if (b == 0) throw runtime_error("Error. Módulo por cero");
    return a % b;
}

// Convierte binario en string (como "10") a entero (2)
int binToInt(const string& bits) {
    return stoi(bits, nullptr, 2);
}

// Decodificador
void decodificarInstruccion(const string& instr, int index) {
    cout << "\nInstrucción " << index + 1 << ": " << instr << endl;

    if (instr.length() != 8 || instr.find_first_not_of("01") != string::npos) {
        cout << "Error. Instrucción inválida (no tiene 8 bits o contiene caracteres inválidos).\n";
        return;
    }

    string opcodeStr = instr.substr(0, 3);
    string modStr = instr.substr(3, 1);
    string aStr = instr.substr(4, 2);
    string bStr = instr.substr(6, 2);

    int opcode = binToInt(opcodeStr);
    bool modFlag = binToInt(modStr);
    int a = binToInt(aStr);
    int b = binToInt(bStr);

    if (modFlag) swap(a, b);

    cout << "OPCODE: " << opcodeStr << " ";
    cout << "(";
    switch (opcode) {
        case 0: cout << "Suma"; break;
        case 1: cout << "Resta"; break;
        case 2: cout << "Multiplicación"; break;
        case 3: cout << "División entera"; break;
        case 5: cout << "Potencia"; break;
        case 6: cout << "Módulo"; break;
        default: cout << "Inválido"; break;
    }
    cout << ")\n";

    cout << "MOD: " << modStr << " (" << (mod ? "Invertir operandos" : "Orden directo") << ")\n";
    cout << "A: " << aStr << " (" << a << ")  ";
    cout << "B: " << bStr << " (" << b << ")\n";

    try {
        int resultado = 0;
        switch (opcode) {
            case 0: resultado = suma(a, b); break;
            case 1: resultado = resta(a, b); break;
            case 2: resultado = multiplicacion(a, b); break;
            case 3: resultado = division(a, b); break;
            case 5: resultado = potencia(a, b); break;
            case 6: resultado = mod(a, b); break;
            default:
                cout << "Error. Opcode inválido\n";
                return;
        }
        cout << "Resultado: " << resultado << endl;
    } catch (const exception& e) {
        cout << e.what() << endl;
    }
}

int main() {
    int opcion;

    do {
        cout << "\n=== Decodificador de Instrucciones 8-bit ===\n";
        cout << "Seleccione una opción:\n";
        cout << "[1] Ingresar instrucciones binarias\n";
        cout << "[0] Salir\n";
        cout << "Opción: ";
        cin >> opcion;
        cin.ignore(); // Para limpiar el salto de línea pendiente

        if (cin.fail()) {
            cout << "Entrada inválida. Debe ingresar un número.\n";
            cin.clear();
            cin.ignore(numeric_limits<streamsize>::max(), '\n');
            continue;
        }

        switch (opcion) {
            case 1: {
                string input;
                cout << "Ingrese las instrucciones binarias (separadas por espacios): ";
                getline(cin, input);

                istringstream iss(input);
                string instruccion;
                vector<string> instrucciones;
                while (iss >> instruccion) {
                    instrucciones.push_back(instruccion);
                }

                for (int i = 0; i < instrucciones.size(); ++i) {
                    decodificarInstruccion(instrucciones[i], i);
                }
                break;
            }

            case 0:
                cout << "Saliendo del programa...\n";
                break;

            default:
                cout << "Opción no válida. Intente de nuevo.\n";
                break;
        }

    } while (opcion != 0);

    return 0;
}
